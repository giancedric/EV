amount = int(input('Number of people in your group:'))
large=amount//7 #amount of people divided by the amount it can feed (// will make it so it divides and doesnt produce a float and remainder)
amount = amount % 7 #modulus will tell how much is left when divided by 7
medium = amount//3 #does the same as 7
amount= amount%3 #tells how much is left when divided by 3
small=amount #the amount when divided by 3 can only be filled by 1s
print(f'You will need {large} large pizzas, {medium} medium pizzas, and {small} small pizzas.')#f string method puts curly brackets within strings as variables