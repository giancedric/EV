x = 'owo'
y= list(x)
print(y)
