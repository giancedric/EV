year = int(input('Input a year:')) #takes the year input
if year % 4 == 0: #asks if the year is divisible by 5 without remainders and prints if it is
    print(str(year) + " is a leap year")
    if year / 100 == 0: #asks if the year ends in 00 and divisible by 4 then prints
        print(str(year) + " is not a leap year")
        if year % 400 == 0: #if it is divisible by 4 and ends in 00 BUT is divible by 400, its a leap year
            print(str(year) + " is a leap year")
else:
    print(str(year) + " is not a leap year")

    
