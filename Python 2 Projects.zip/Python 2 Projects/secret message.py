code = { "a": "q", "b": "x", "c": "j", "d": "z", "e": "v", "f": "p", "g": "k", "h": "u", "i": "w", "j": "y", "k": "b", "l": "t", "m": "r", "n": "d", "o": "h", "p": "s", "q": "e", "r": "a", "s": "i", "t": "f", "u": "l", "v": "g", "w": "o", "x": "n", "y": "c", "z": "m", " ": "1" }
message = input("Enter Your Message: ")
encoded_message= ""
for char in message: #for every character in user input
    encoded_message+=code.get(char) #In programming, char is a common abbreviation for "character." It typically refers to a single unit of text, such as a letter, digit, or symbol. So its getting the value of the corresponding key of the message and appending it to the encoded message string

print(encoded_message)