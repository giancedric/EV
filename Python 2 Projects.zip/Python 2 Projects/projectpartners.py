def assign_partners():

    students = input("Input the list of students: ")
    studentslist = students.split() #makes a list of the students

    sortedlist = sorted(studentslist)#sorts the studnets alphabetically

    partners = [] #created empty list to put in names
    
    while len(sortedlist) > 1:
        #popping gets rid of the items in a list but when u use it in a variable it will still appear
        f = sortedlist.pop(0) #first place/a

        l = sortedlist.pop(-1) #last place/z

        partners.append((f,l)) #adding to partners list/ partners.add(first and last) in a tuple

    for pair in partners: #for every tuple/pair in the list it will print each pair
        print(pair)
    return partners #isnt really needed but it makes partners be usable for other functions.




assign_partners() #calling the function