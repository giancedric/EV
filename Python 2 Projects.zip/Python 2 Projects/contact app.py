
answer = 'y'
contacts = []


while answer == "y":
    name = input("Enter a first and last name: ")
    contacts.append(name)
    answer = input('Do you want to add more contacts? Y or N: ')
    if answer.lower() == 'n':
        contacts.sort()
        print(contacts)

