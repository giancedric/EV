words = ["elephant", "jungle",
"sunshine",
"computer",
"morning",
"sunflower",
"vacation",
"fantastic",
"journey",
"wonder",
"giraffe"
]

turns = 12

number = int(input('Enter a number from 0-10:'))
chosen=words[number]#indexing the list with the user input
lit = list(chosen) #makes the chosen word a list like .split()

while turns > 0:
    myletter=input('Enter a letter:')
    turns -= 1
    if myletter in lit:
        print("Correct letter: " + myletter)
    if myletter not in lit:
            print("-")
    
            
