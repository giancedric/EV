print('Nishida' + ' 1')
print('Onodera' + ' 2')
print('Fukatsu' +' 3')
print('Ran'+ ' 12')
print('Ishikawa' + ' 14')
print('Miyaura' + ' 4')
print('Otsuka' +' 5')
print('Yamauchi' +' 6')
print('Kai ' + '15')
print('Yamamoto ' +'20')
string1 = 'Welcome to the team! Your team number is {}'
Yamamoto=20
print(string1.format(Yamamoto)) 