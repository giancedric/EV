int1 = 12
int2 = 56
print(int1 + int2)
print(int1 - int2)
print(int1 * int2)
print(int1 / int2)