#our school is participating in a reading competition. Create a program that will print out how many total pages have been read for your class and for your school if everyone read 20 pages. The purpose of this assignment is to practice writing using Python syntax to solve math problems.
student = 20
classroom = student * 30
print(classroom)
school = classroom * 12
print(school)
goal = 10000
pagesperstudent = goal/360
print(float(pagesperstudent))