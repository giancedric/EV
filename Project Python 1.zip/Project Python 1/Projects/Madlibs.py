noun1 = input("Choose a noun:")
pnoun1 = input('Choose a plural noun:')
noun2 = input('Choose a noun:')
place = input('Choose a place:')
adjective = input('Choose an adjective:')
print("Did you know I have a pet " + noun1 + '?' + " He likes to run around and play with all of the " + pnoun1+ '.' + " One morning, I woke up and he was wearing a " + noun2 + ' for a hat!' + ' I especially like to take him to the ' +  place + ' because he shows off his ' + adjective + ' side.')
#Make your computer talk! For this lesson we are going to use inputs and print statements to make your computer talk.