oog = ['poop', 'dog', 'mother', 'drag', 'rupaul', 'nymphia', 'gian', 'dick', 'balls', 'cock']
for x in oog:
    print('While I was taking my ' + x + ' for a walk, another giant ' + x + ' came out of nowhere and chased me all the way home!')